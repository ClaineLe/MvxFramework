namespace MvxFramework.UnityEngine.Views
{
    public interface IMvxUnityApplication
    {
    }
}