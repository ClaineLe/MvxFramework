namespace MvxFramework.UnityEngine.Views
{
    public interface IMvxUIUnit
    {
        IMvxUIUnit ParentUI { get; }
    }
}