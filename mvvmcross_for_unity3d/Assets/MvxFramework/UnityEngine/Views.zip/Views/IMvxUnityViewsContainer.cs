using MvvmCross.Views;

namespace MvxFramework.UnityEngine.Views
{
    public interface IMvxUnityViewsContainer : IMvxViewsContainer, IMvxUnityViewCreator
    {
    }
}