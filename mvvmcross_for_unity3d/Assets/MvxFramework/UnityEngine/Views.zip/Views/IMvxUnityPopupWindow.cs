namespace MvxFramework.UnityEngine.Views
{
    public interface IMvxUnityPopupWindow
    {
    }
}