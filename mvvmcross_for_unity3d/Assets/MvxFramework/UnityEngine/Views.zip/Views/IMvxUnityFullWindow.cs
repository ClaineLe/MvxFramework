namespace MvxFramework.UnityEngine.Views
{
    public interface IMvxUnityFullWindow
    {
        public int Priority { get; }
    }
}